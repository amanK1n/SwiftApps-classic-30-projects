//
//  MoviePersistenceManager.swift
//  MovieApp
//
//  Created by Sayed on 25/08/25.
//

import CoreData
import UIKit
class CachedImage {
    let image: UIImage
    let expiryDate: Date
    
    init(image: UIImage, ttl: TimeInterval) {
        self.image = image
        self.expiryDate = Date().addingTimeInterval(ttl)
    }
    
    var isExpired: Bool {
        return Date() > expiryDate
    }
}

class MoviePersistenceManager {
    static let shared = MoviePersistenceManager()
    private init() {}
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    private let imageCache = NSCache<NSNumber, CachedImage>()
    private let cacheTTL: TimeInterval = 86400
    func saveMovies(_ movies: [MovieDataUIModel], posterImages: [Int: UIImage], category: MovieCategory) {
        for movie in movies {
            let entity = MovieEntity(context: context)
            entity.id = Int64(movie.id)
            entity.title = movie.title
            entity.overview = movie.overview
            entity.genreIds = movie.genreIds.map { String($0) }.joined(separator: ",")
            entity.category = category.rawValue
            // save image if available
            if let image = posterImages[movie.id] {
                print("Saving image CDCDCDCD")
                let fileName = "\(movie.id).png"
                if let savedFile = FileStorage.saveImage(image, fileName: fileName) {
                    entity.posterFile = savedFile
                    let cached = CachedImage(image: image, ttl: cacheTTL)
                    imageCache.setObject(cached, forKey: NSNumber(value: movie.id))
                }
            } else {
                print("Saving poster path")
                entity.posterFile = movie.posterPath // fallback: store URL if no image downloaded yet
            }
        }
        
        do {
            try context.save()
            print("✅ Movies saved successfully in Core Data")
        } catch {
            print("❌ Error saving movies:", error)
        }
    }
    func fetchMovies(for category: MovieCategory) -> [MovieDataUIModel] {
        
        let fetchRequest: NSFetchRequest<MovieEntity> = MovieEntity.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "category == %@", category.rawValue)
        do {
            print("Fetch Movie core data")
            let movies = try context.fetch(fetchRequest)
            return movies.map { entity in
                let genres = entity.genreIds?.split(separator: ",").compactMap { Int($0) } ?? []
                return MovieDataUIModel(
                    id: Int(entity.id),
                    title: entity.title ?? "",
                    overview: entity.overview ?? "",
                    posterPath: entity.posterFile ?? "", // this will be filename
                    genreIds: genres
                )
            }
        } catch {
            print("❌ Error fetching movies:", error)
            return []
        }
    }

    func getPosterImage(for movie: MovieDataUIModel) -> UIImage? {
        print("Getting image from core data PERSISTENCE")
        let key = NSNumber(value: movie.id)
        if let cached = imageCache.object(forKey: key) {
            if !cached.isExpired {
                print("✅ Loaded from memory cache NOT EXP")
                return cached.image
            } else {
                print("⚠️ Expired, removing from cache")
                imageCache.removeObject(forKey: key)
            }
        }
        if let image = FileStorage.loadImage(fileName: "\(movie.id).png") {
            print("✅ Loaded from disk and caching in memory")
            let cached = CachedImage(image: image, ttl: cacheTTL)
            imageCache.setObject(cached, forKey: key)
            return image
        }
        
        return nil
    }

    
}

