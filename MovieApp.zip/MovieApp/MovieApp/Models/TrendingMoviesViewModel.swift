//
//  TrendingMoviesViewModel.swift
//  MovieApp
//
//  Created by Sayed on 24/08/25.
//

import Foundation

// MARK: - Flow Delegate
public protocol TrendingMoviesFlowDelegate: AnyObject {
    func actionFetchTrendingMoviesSuccessful(data: TrendingMoviesDataUIModel)
    func actionFetchTrendingMoviesFailed(error: TrendingMoviesErrorUIModel)
}

// MARK: - Dependency
public protocol TrendingMoviesDependency: AnyObject {
    func getLanguageCode() -> String?
//    func getPageNumber() -> Int?
}

// MARK: - DataSource
public class TrendingMoviesDataSource {
    func callTrendingMoviesAPI(language: String?,
                               successCallBack: @escaping (TrendingMoviesResponseModel) -> Void,
                               failureCallBack: @escaping (Error) -> Void) {

        var endpoint = "/trending/movie/day"
        var queryItems: [String] = []

        if let language = language {
            queryItems.append("language=\(language)")
        }
//        if let page = page {
//            queryItems.append("page=\(page)")
//        }
        if !queryItems.isEmpty {
            endpoint.append("?" + queryItems.joined(separator: "&"))
        }

        APIClient.shared.request(endpoint: endpoint) { (result: Result<TrendingMoviesResponseModel, APIError>) in
            switch result {
            case .success(let response):
                successCallBack(response)
            case .failure(let error):
                failureCallBack(error)
            }
        }
    }
}

// MARK: - ViewModel
public class TrendingMoviesViewModel {
    let dataSource: TrendingMoviesDataSource

    /// Flow Delegate
    public weak var delegate: TrendingMoviesFlowDelegate?

    /// Dependency
    public weak var component: TrendingMoviesDependency?

    init(delegate: TrendingMoviesFlowDelegate?,
         component: TrendingMoviesDependency?,
         dataSource: TrendingMoviesDataSource) {
        self.dataSource = dataSource
        self.delegate = delegate
        self.component = component
    }

    /// Convenience init
    public convenience init(delegate: TrendingMoviesFlowDelegate? = nil,
                            component: TrendingMoviesDependency? = nil) {
        self.init(delegate: delegate,
                  component: component,
                  dataSource: TrendingMoviesDataSource())
    }

    /// Perform API call
    public func fetchTrendingMovies() {
        let language = component?.getLanguageCode()
        //let page = component?.getPageNumber()

        dataSource.callTrendingMoviesAPI(language: language,
                                         successCallBack: { [weak self] response in
            let movies = response.results.map {
                MovieDataUIModel(id: $0.id, title: $0.title, overview: $0.overview)
            }
            let uiModel = TrendingMoviesDataUIModel(results: movies)
            self?.delegate?.actionFetchTrendingMoviesSuccessful(data: uiModel)
        }, failureCallBack: { [weak self] error in
            let errorModel = TrendingMoviesErrorUIModel(statusCode: "-1",
                                                        statusMessage: error.localizedDescription)
            self?.delegate?.actionFetchTrendingMoviesFailed(error: errorModel)
        })
    }
}
