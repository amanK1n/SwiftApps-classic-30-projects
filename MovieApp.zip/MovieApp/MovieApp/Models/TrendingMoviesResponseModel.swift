//
//  TrendingMoviesResponseModel.swift
//  MovieApp
//
//  Created by Sayed on 24/08/25.
//

import Foundation
// MARK: - Response Models

public class MovieResponseModel: Decodable {
    let id: Int
    let title: String
    let overview: String

    enum CodingKeys: String, CodingKey {
        case id
        case title
        case overview
    }

    required public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(Int.self, forKey: .id)
        title = try container.decode(String.self, forKey: .title)
        overview = try container.decode(String.self, forKey: .overview)
    }
}

public class TrendingMoviesResponseModel: Decodable {
    let results: [MovieResponseModel]

    enum CodingKeys: String, CodingKey {
        case results
    }

    required public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        results = try container.decode([MovieResponseModel].self, forKey: .results)
    }
}
