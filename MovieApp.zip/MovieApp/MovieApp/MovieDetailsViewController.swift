//
//  MovieDetailsViewController.swift
//  MovieApp
//
//  Created by Sayed on 23/08/25.
//

import UIKit

class MovieDetailsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.isNavigationBarHidden = false
        view.backgroundColor = UIColor.red
    }

}
