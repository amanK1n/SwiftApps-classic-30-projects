//
//  TrendingMoviesResponseModel.swift
//  MovieApp
//
//  Created by Sayed on 24/08/25.
//

import Foundation
// MARK: - Response Models

public class MovieResponseModel: Decodable {
    let id: Int
    let title: String
    let overview: String
    let posterPath: String
    let genreIds: [Int]
    enum CodingKeys: String, CodingKey {
        case id
        case title
        case overview
        case posterPath = "poster_path"
        case genreIds = "genre_ids"
    }

    required public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(Int.self, forKey: .id)
        title = try container.decode(String.self, forKey: .title)
        overview = try container.decode(String.self, forKey: .overview)
        posterPath = try container.decode(String.self, forKey: .posterPath)
        genreIds = try container.decode([Int].self, forKey: .genreIds)
    }
}

public class TrendingMoviesResponseModel: Decodable {
    let results: [MovieResponseModel]

    enum CodingKeys: String, CodingKey {
        case results
    }

    required public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        results = try container.decode([MovieResponseModel].self, forKey: .results)
    }
}
