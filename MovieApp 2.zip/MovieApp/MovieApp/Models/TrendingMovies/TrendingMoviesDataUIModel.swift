//
//  TrendingMoviesModel.swift
//  MovieApp
//
//  Created by Sayed on 24/08/25.
//

import Foundation

public struct TrendingMoviesErrorUIModel {
    public let statusCode: String
    public let statusMessage: String
    public init(statusCode: String, statusMessage: String = "") {
        self.statusCode = statusCode
        self.statusMessage = statusMessage
    }
}

public struct MovieDataUIModel {
    let id: Int
    let title: String
    let overview: String
    let posterPath: String
    let genreIds: [Int]
    init(id: Int, title: String, overview: String, posterPath: String, genreIds: [Int]) {
        self.id = id
        self.title = title
        self.overview = overview
        self.posterPath = posterPath
        self.genreIds = genreIds
    }
}
public struct TrendingMoviesDataUIModel {
    let results: [MovieDataUIModel]
    init(results: [MovieDataUIModel]) {
        self.results = results
    }
}
