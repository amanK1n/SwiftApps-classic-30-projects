//
//  MovieDetailsViewController.swift
//  MovieApp
//
//  Created by Sayed on 23/08/25.
//

import UIKit

class MovieDetailsViewController: UIViewController {

    @IBOutlet public var backImageIcon: UIImageView?
    
    @IBOutlet public var detailImage: UIImageView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackImage()
        setupDetailImage()
        view.backgroundColor = UIColor.red
        
    }
    
    func setupBackImage() {
        let backImage = UIImage(named: "right-arrow")?.withHorizontallyFlippedOrientation().withTintColor(.white)
        backImageIcon?.image = backImage
        backImageIcon?.backgroundColor = .lightGray
        backImageIcon?.layer.cornerRadius = 12.0
        backImageIcon?.layer.masksToBounds = true
        backImageIcon?.clipsToBounds = true
        backImageIcon?.contentMode = .scaleAspectFit
        backImageIcon?.isUserInteractionEnabled = true
        let inset: CGFloat = 2
        let paddedImage = backImage?.withAlignmentRectInsets(
            UIEdgeInsets(top: 0, left: inset, bottom: 0, right: inset)
        )

        backImageIcon?.image = paddedImage
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(backButtonTapped))
        backImageIcon?.addGestureRecognizer(tapGesture)
    }
    @objc func backButtonTapped() {
        self.navigationController?.popViewController(animated: true)
    }
    func setupDetailImage() {
        detailImage?.image = UIImage(named: "nssl0033.jpg")
        detailImage?.contentMode = .scaleAspectFill
        detailImage?.clipsToBounds = true
    }
    
}
