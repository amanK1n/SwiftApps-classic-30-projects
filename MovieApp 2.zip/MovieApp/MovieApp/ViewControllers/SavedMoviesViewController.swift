//
//  SavedMoviesViewController.swift
//  MovieApp
//
//  Created by Sayed on 23/08/25.
//

import UIKit

class SavedMoviesViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        view.backgroundColor = UIColor.blue
    }



}
