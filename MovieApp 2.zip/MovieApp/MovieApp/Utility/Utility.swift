//
//  Utility.swift
//  MovieApp
//
//  Created by Sayed on 24/08/25.
//

import Foundation
import UIKit

class Utility {

    // MARK: - Genre Resolver
    private static let genreResolver: [Int: String] =
         [
            28: "Action",
            12: "Adventure",
            16: "Animation",
            35: "Comedy",
            80: "Crime",
            99: "Documentary",
            18: "Drama",
            10751: "Family",
            14: "Fantasy",
            36: "History",
            27: "Horror",
            10402: "Music",
            9648: "Mystery",
            10749: "Romance",
            878: "Science Fiction",
            10770: "TV Movie",
            53: "Thriller",
            10752: "War",
            37: "Western"
        ]
    
//
//    static func getGenreName(for id: Int) -> String {
//        return genreResolver[id] ?? "Unknown"
//    }

    static func getGenreNames(for ids: [Int]) -> [String] {
        return ids.map { genreResolver[$0] ?? "Unknown" }
    }
}

// MARK: - UIImageView Extension inside Utility
extension UIImageView {
    func loadImage(from url: URL?) {
        guard let url = url else {
            self.image = UIImage(systemName: "photo") // fallback placeholder
            return
        }
        URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            if let data = data, error == nil {
                DispatchQueue.main.async {
                    self?.image = UIImage(data: data)
                }
            }
        }.resume()
    }
}
